"""方案 A：一键自动配置生成器

输入: 列表页 URL
输出: sites.yaml 配置片段

流程:
  1. 打开列表页 → 等 CF
  2. markdown 提取链接 → 按路径模式聚类 → 自动识别详情页链接组
  3. 进入第一个详情页 → 找播放器 → 点击 → 抓 m3u8
  4. 分析翻页结构
  5. 输出完整配置
"""

import re
import time
from collections import Counter
from dataclasses import dataclass, field
from urllib.parse import urlparse
from typing import Optional

from crawler.browser_act import BrowserActClient


@dataclass
class AutoConfigResult:
    """自动配置结果。"""
    success: bool = False
    config: dict = field(default_factory=dict)
    log: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def _path_pattern(url: str) -> str:
    """将 URL 路径转为模式：数字段替换为 {id}。"""
    parsed = urlparse(url)
    path = parsed.path
    parts = list(path.split("/"))
    new_parts = []
    for p in parts:
        if not p:
            new_parts.append(p)
            continue
        # 处理 "123.html" 这种格式：拆成 "123" + ".html"
        base_name = p
        ext = ""
        if "." in p:
            base_name, ext = p.rsplit(".", 1)
            ext = "." + ext
        # 检查 base_name 是否是纯数字或十六进制
        if re.match(r"^\d+$", base_name):
            new_parts.append("{id}" + ext)
        elif re.match(r"^[a-f0-9]{8,}$", base_name, re.IGNORECASE):
            new_parts.append("{id}" + ext)
        else:
            new_parts.append(p)
    return "/".join(new_parts)


def _cluster_links(links: list[dict], base_url: str) -> list[dict]:
    """将链接按路径模式聚类，返回 [{pattern, count, links}]。"""
    base_netloc = urlparse(base_url).netloc
    internal = [
        l for l in links
        if (urlparse(l["url"]).netloc == base_netloc or not urlparse(l["url"]).netloc)
        and urlparse(l["url"]).path not in ("", "/")
    ]

    # 聚类
    groups = {}  # pattern -> [links]
    for l in internal:
        pat = _path_pattern(l["url"])
        if pat not in groups:
            groups[pat] = []
        groups[pat].append(l)

    # 排序：含 {id} 的优先，数量多的优先
    results = []
    for pat, lnks in groups.items():
        if "{id}" not in pat:
            continue  # 跳过没有 ID 占位符的（列表页自身等）
        results.append({
            "pattern": pat,
            "count": len(lnks),
            "links": lnks,
        })

    results.sort(key=lambda x: x["count"], reverse=True)
    return results


def _try_capture_stream(
    client: BrowserActClient,
    snap: "StateSnapshot",
    result: AutoConfigResult,
    max_attempts: int = 8,
    poll_interval: float = 1.5,
) -> Optional[str]:
    """网络优先：以"捕获到流地址"为唯一成功标准，交互只是触发手段。

    交互策略优先级：
    1. 直接查 network（页面可能自动播放了）
    2. 点播放按钮（"立即播放"/"在线播放"等）
    3. 点 video/iframe 元素（触发播放）
    4. 选第一个集数标签
    5. 选第一个线路标签
    6. JS 提取兜底
    """
    from crawler.fast_crawler import _extract_stream_from_network, _extract_stream_from_js

    client.network_clear()

    # ── 策略 1: 直接查 network（自动播放页面）
    stream = _extract_stream_from_network(client)
    if stream:
        result.log.append("  策略1: 页面自动播放，直接捕获")
        return stream

    # ── 策略 2: 点播放按钮
    play_keywords = {"立即播放", "在线播放", "播放", "Play", "play", "播放视频"}
    play_btn = None
    for el in snap.elements:
        if el.text.strip() in play_keywords and el.tag in ("a", "button"):
            play_btn = el
            break
    if not play_btn:
        for el in snap.elements:
            cls = (el.class_name or "").lower()
            if "play" in cls and el.tag in ("a", "button"):
                play_btn = el
                break

    if play_btn:
        result.log.append(f"  策略2: 点击播放按钮 [{play_btn.index}] '{play_btn.text.strip()}'")
        client.click(play_btn.index)
        # 轮询等待流出现
        for _ in range(max_attempts):
            time.sleep(poll_interval)
            stream = _extract_stream_from_network(client)
            if stream:
                return stream

    # ── 策略 3: 点 video/iframe 元素
    for el in snap.elements:
        if el.tag in ("video", "iframe"):
            result.log.append(f"  策略3: 点击 {el.tag} 元素 [{el.index}]")
            client.click(el.index)
            for _ in range(max_attempts):
                time.sleep(poll_interval)
                stream = _extract_stream_from_network(client)
                if stream:
                    return stream
            break  # 只点第一个 video/iframe

    # ── 策略 4: 选第一个集数标签
    episode_keywords = {"集", "ep", "episode", "第"}
    for el in snap.elements:
        t = el.text.strip()
        if any(kw in t.lower() for kw in episode_keywords) and el.tag == "a" and len(t) < 20:
            result.log.append(f"  策略4: 点击集数 [{el.index}] '{t}'")
            client.click(el.index)
            for _ in range(max_attempts):
                time.sleep(poll_interval)
                stream = _extract_stream_from_network(client)
                if stream:
                    return stream
            break

    # ── 策略 5: 选第一个线路标签
    route_keywords = {"线路", "播放源", "源", "source", "line"}
    for el in snap.elements:
        t = el.text.strip()
        if any(kw in t.lower() for kw in route_keywords) and el.tag == "a" and len(t) < 20:
            result.log.append(f"  策略5: 点击线路 [{el.index}] '{t}'")
            client.click(el.index)
            for _ in range(max_attempts):
                time.sleep(poll_interval)
                stream = _extract_stream_from_network(client)
                if stream:
                    return stream
            break

    # ── 策略 6: JS 提取兜底
    result.log.append("  策略6: JS 提取兜底")
    stream = _extract_stream_from_js(client)
    if stream:
        return stream

    return None


def _detect_url_increment(url: str) -> Optional[dict]:
    """检测 URL 是否为数字递增翻页模式。

    例: https://www.mimimi.top/vodtype/3-6.html
      → template: /vodtype/3-{page}.html, current_val=6
    """
    from urllib.parse import urlparse, urlunparse
    parsed = urlparse(url)
    path = parsed.path

    # 找 path 中所有数字段
    matches = list(re.finditer(r'(\d+)', path))
    if not matches:
        return None

    # 优先取最后一个数字段作为页码
    last = matches[-1]
    num_val = int(last.group(1))

    # 如果末尾数字太大(>500)，可能不是页码，试倒数第二个
    if num_val > 500 and len(matches) >= 2:
        last = matches[-2]
        num_val = int(last.group(1))
        if num_val > 500:
            return None
    elif num_val > 500:
        return None

    start, end = last.start(), last.end()
    template = path[:start] + "{page}" + path[end:]
    next_val = num_val + 1
    next_path = path[:start] + str(next_val) + path[end:]
    next_url = urlunparse((parsed.scheme, parsed.netloc, next_path, parsed.params, parsed.query, ""))

    return {
        "template": template,
        "current_val": num_val,
        "next_url": next_url,
    }


def auto_config(
    list_url: str,
    client: BrowserActClient,
    max_wait_cf: int = 60,
) -> AutoConfigResult:
    """一键自动配置。

    Args:
        list_url: 列表页 URL
        client: BrowserActClient 实例（会自动复用已有会话或重建）
        max_wait_cf: CF 验证最长等待秒数

    Returns:
        AutoConfigResult
    """
    result = AutoConfigResult()

    # ── Step 1: 打开列表页 ──────────────────────────────
    result.log.append(f"[1] 打开列表页: {list_url}")
    try:
        snap = client.ensure_session(url=list_url, max_wait_cf=max_wait_cf)
    except RuntimeError as e:
        result.errors.append(str(e))
        result.log.append(f"  ❌ {e}")
        return result

    result.log.append(f"  ✅ 页面加载: {snap.title[:60]}")
    list_snap = snap

    # ── Step 1.5: 分析翻页 ───────────────────────────
    # 优先用 URL 数字递增模式识别（无需浏览器交互）
    result.log.append("[1.5] 分析翻页...")
    ptype = "none"
    current = 0
    total = 1
    pagination = None
    url_increment_pattern = None  # (template, current_val)

    url_inc = _detect_url_increment(list_url)
    if url_inc:
        result.log.append(f"  URL 数字递增模式: {url_inc['template']} (当前={url_inc['current_val']})")
        # 验证下一页是否存在
        next_url = url_inc['next_url']
        result.log.append(f"  验证下一页: {next_url}")
        try:
            import urllib.request
            req = urllib.request.Request(next_url, headers={'User-Agent': 'Mozilla/5.0'})
            resp = urllib.request.urlopen(req, timeout=10)
            if resp.status == 200:
                ptype = "url_increment"
                current = url_inc['current_val']
                total = 0  # 未知，爬取时动态发现
                url_increment_pattern = url_inc
                result.log.append(f"  ✅ URL递增翻页确认: page {current} → {current+1}")
            else:
                result.log.append(f"  下一页返回 {resp.status}，非递增模式")
        except Exception as e:
            result.log.append(f"  下一页验证失败: {e}")
    else:
        result.log.append("  URL 无数字递增模式，回退到 DOM 检测")

    # 如果 URL 递增没识别出来，回退到 DOM 检测
    if ptype == "none":
        # 滚动到底部让翻页元素加载出来
        for _ in range(8):
            client.scroll_down()
        time.sleep(1)
        list_snap_scrolled = client.parsed_state()
        pagination = list_snap_scrolled.find_pagination_info() if hasattr(list_snap_scrolled, 'find_pagination_info') else None

        if pagination:
            if isinstance(pagination, dict):
                ptype = pagination.get('type', 'unknown')
                current = pagination.get('current_page', 0)
                total = pagination.get('total_pages', 0)
            else:
                ptype = getattr(pagination, 'type', 'unknown')
                current = getattr(pagination, 'current_page', 0)
                total = getattr(pagination, 'total_pages', 0)
            result.log.append(f"  DOM 翻页: type={ptype}, current={current}, total={total}")
        else:
            result.log.append("  未检测到翻页结构")

        # 回到顶部
        client.scroll_top()
        time.sleep(1)

    # ── Step 2: 提取链接 & 聚类 ─────────────────────────
    result.log.append("[2] 提取链接 & 聚类...")
    md = client.get_markdown()
    from crawler.fast_crawler import extract_links_from_markdown

    raw_links = extract_links_from_markdown(md, base_url=list_url)
    result.log.append(f"  原始链接: {len(raw_links)}")

    clusters = _cluster_links(raw_links, list_url)

    if not clusters:
        result.errors.append("无法识别详情页链接模式")
        result.log.append("  ❌ 没有找到含 ID 的链接模式")
        return result

    # 展示 top 3
    for i, c in enumerate(clusters[:3]):
        result.log.append(f"  模式 {i+1}: {c['pattern']} ({c['count']} 个)")
        if c['links']:
            result.log.append(f"    示例: {c['links'][0]['text'][:40]} → {c['links'][0]['url'][:60]}")

    # 选择最佳聚类：启发式优先级
    # 1. 路径含 detail/play/video/episode 的是详情页
    # 2. 数量在 3-500 范围内（排除过少或导航链接）
    # 3. 数量越多越好
    DETAIL_KEYWORDS = ["detail", "play", "episode", "movie", "view", "show"]
    EXCLUDE_KEYWORDS = ["type", "class", "categor", "tag", "search", "sort"]

    scored = []
    for c in clusters:
        score = 0
        # 关键词加分
        pat_lower = c["pattern"].lower()
        excluded = any(kw in pat_lower for kw in EXCLUDE_KEYWORDS)
        if excluded:
            score -= 200  # 排除分类/导航页
        for kw in DETAIL_KEYWORDS:
            if kw in pat_lower:
                score += 100
                break
        # 路径深度加分（详情页通常更深）
        depth = c["pattern"].count("/")
        score += depth * 10
        # 数量分
        if 3 <= c["count"] <= 500:
            score += 50
        elif c["count"] > 500:
            score += 20  # 太多可能是导航
        scored.append((score, c))

    scored.sort(key=lambda x: x[0], reverse=True)
    best = scored[0][1]
    detail_links = best["links"]
    detail_pattern = best["pattern"]

    # 判断内容类型：如果 URL 包含 video/play 等关键词，是视频；包含 pic/photo/image，是图集；否则默认视频
    content_type = "video"
    if any(kw in detail_pattern.lower() for kw in ["pic", "photo", "image", "art", "gallery", "album"]):
        content_type = "art"

    result.log.append(f"  选择: {detail_pattern} ({len(detail_links)} 个链接), 类型: {content_type}")

    # ── Step 3: 进入详情页提取流地址 ─────────────────────
    first_detail = detail_links[0]
    detail_url = first_detail["url"]
    result.log.append(f"[3] 进入详情页: {detail_url[:80]}")

    client.navigate(detail_url)
    # 轮询等页面就绪：非 CF + 有主要内容（播放按钮/视频/iframe/多个链接）
    snap = None
    for attempt in range(15):
        time.sleep(1)
        try:
            snap = client.parsed_state()
            t = snap.title.lower()
            if "moment" in t or "稍候" in t or "verify" in t or "checking" in t:
                continue
            # 页面非 CF，检查是否有实质性内容
            has_content = (
                any(el.tag in ("video", "iframe") for el in snap.elements)
                or any(el.text.strip() in {"立即播放", "在线播放", "播放", "Play", "play"} and el.tag in ("a", "button") for el in snap.elements)
                or sum(1 for el in snap.elements if el.tag == "a") >= 5
            )
            if has_content:
                break
        except RuntimeError:
            continue

    stream_url = None
    stream_format = ""

    if content_type == "video" and snap:
        stream_url = _try_capture_stream(client, snap, result)

        if stream_url:
            from crawler.fast_crawler import _detect_format
            stream_format = _detect_format(stream_url)
            result.log.append(f"  ✅ 流地址: {stream_url[:80]}")
            result.log.append(f"  格式: {stream_format}")
        else:
            result.log.append("  ⚠️ 未抓到流地址（可能需要手动配置）")
    elif content_type == "art":
        # 图集：提取图片
        from crawler.fast_crawler import _extract_images_combined
        images = _extract_images_combined(client)
        result.log.append(f"  图片: {len(images)} 张")

    # ── Step 4: 生成配置 ────────────────────────────────
    result.log.append("[4] 生成配置...")

    parsed = urlparse(list_url)
    site_name = parsed.netloc.replace(".", "_")
    base_url = f"{parsed.scheme}://{parsed.netloc}"

    # 推断 link_pattern 正则
    link_pattern_re = detail_pattern.replace("{id}", r"\d+")

    config = {
        "name": site_name,
        "base_url": base_url,
        "entry_points": [list_url],
        "link_patterns": {
            "video_detail": [link_pattern_re] if content_type == "video" else [],
            "art_detail": [link_pattern_re] if content_type == "art" else [],
        },
        "pagination": {
            "type": ptype if pagination else ("url_increment" if url_increment_pattern else "unknown"),
            "total_pages": total if pagination else 1,
        },
    }

    # 如果是 URL 递增翻页，加模板信息
    if url_increment_pattern:
        config["pagination"]["url_template"] = url_increment_pattern["template"]
        config["pagination"]["start_page"] = url_increment_pattern["current_val"]
        "extract_chains": [],
    }

    # 添加提取链
    if stream_url:
        if ".m3u8" in stream_url:
            config["extract_chains"] = [
                {"name": "m3u8_stream", "method": "network_capture", "filter": ".m3u8"}
            ]
        elif ".mp4" in stream_url:
            config["extract_chains"] = [
                {"name": "mp4_stream", "method": "network_capture", "filter": ".mp4"}
            ]
    elif content_type == "art":
        config["extract_chains"] = [
            {"name": "images", "method": "css_selector", "selector": "img"}
        ]

    result.config = config
    result.success = True
    result.log.append("  ✅ 配置生成完成")

    return result


def format_config_yaml(config: dict) -> str:
    """将配置格式化为可读 YAML。"""
    import yaml
    return yaml.dump(config, allow_unicode=True, default_flow_style=False, sort_keys=False)
